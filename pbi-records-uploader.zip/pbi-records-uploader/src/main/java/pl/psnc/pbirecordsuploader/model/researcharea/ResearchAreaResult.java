package pl.psnc.pbirecordsuploader.model.researcharea;

public record ResearchAreaResult(String cleanedVal, String URI) {}