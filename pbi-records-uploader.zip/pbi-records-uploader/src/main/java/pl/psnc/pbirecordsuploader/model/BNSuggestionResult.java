package pl.psnc.pbirecordsuploader.model;

public record BNSuggestionResult(String label, String uri) {}