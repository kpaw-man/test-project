package pl.psnc.pbirecordsuploader.exceptions.descriptor;

public class DescriptorException extends Exception {

    public DescriptorException(String message) {
        super(message);
    }

    public DescriptorException(String message, Throwable cause) {
        super(message, cause);
    }
}